package demo.controller;
/*
 * demo/controller/LoadThread.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * <p>
 * This is a thread for generating garbage for the garbage collector.
 * Demonstrates the advantages of having priorities that really work 
 * and the Metronome garbage collector.
 * </p>
 * <p>
 * The load can be changed from the default with the 
 * <code>demo.controller.rtloadthread.load</code> property. 
 * The default is 300000.
 * </p>
 */
public class LoadThread extends Thread {
    
    static final int load;
    static {
        String loadStr = System.getProperty("demo.controller.loadthread.load");
        
        if (loadStr != null) {
            load = Integer.parseInt(loadStr);
        } else {
            load = 300000;
        }
        
    }
    
    public LoadThread() {
        this.setName("LoadThread");
        this.setDaemon(true);
    }
    
    public static volatile long[][] array;
    
    public void run() {
        
        while (true) {
            int count = 0;
            
            array = new long[load][];
            for (int n = 0; n < array.length; n++) {
                array[count] = new long[50];
                if (count++ % 1000 == 0) {
                    try {
                        sleep(1);
                    } catch (InterruptedException e) {
                        // Ignore this
                    }
                }
            }
            
        }
    }
}
