package demo.controller;

import java.io.IOException;
import java.net.SocketException;

import demo.comms.RadarPort;
/*
 * demo/controller/JavaRadar.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * <p>
 * This class is a Thread that times the time it takes to send a "PING"
 * packets to the simulation and receive the "PONG" packets. The length of the
 * delay is proportional to the height. The minimum period is 5ms, which
 * increases, depending on the height.
 * </p>
 * <p>
 * This Radar class is written for low heights. The greater the height, 
 * the less frequently the height will be updated. When the height is at, 
 * say, 10000 units, the delay will be 5 seconds. During that time the 
 * position of the lander will have changed so much that the speed and height 
 * will be very inaccurate. As the controller doesn't anticipate the effects of 
 * accleration, the vertical speed will not be properly controlled.
 * </p>
 */
public class JavaRadar extends Thread implements Radar {
    private RadarPort radarPort;

    public JavaRadar(RadarPort radarPort) {
        this.setName("JavaRadar");
        this.radarPort = radarPort;
    }

    private volatile boolean running = true;

    /**
     * Times a ping/pong and calculates an estimated height for the lander.
     * 
     */
    public void run() {
        try {
            double height = 0.0, lastheight;

            long nanos = System.nanoTime(), lastnanos;
            while (this.running) {
                /* Set the height every x milliseconds */
                Thread.sleep(5);
                lastnanos = nanos;
                lastheight = height;

                nanos = System.nanoTime();

                this.radarPort.ping();

                // Time scale is height units per millisecond
                height = ((System.nanoTime() - nanos) / 1.0e6)
                        / demo.sim.RadarThread.timeScale;

                double speed = (height - lastheight)
                        / (((double) (nanos - lastnanos)) / 1.0e9);

                this.myHeight = height;
                this.mySpeed = speed;
            }
        } catch (SocketException e) {
            // The socket exception is expected if this.running is false.
            if (this.running == true) {
                System.err.println("SocketException in RadarThread " + e);
                e.printStackTrace();
            }
        } catch (IOException e) {
            System.err.println("IOException in RadarThread");
            e.printStackTrace();
        } catch (InterruptedException e) {
            // This is the normal exit procedure.
        }
        
        this.radarPort.stop();  
        this.radarPort.close();
    }

    /**
     * Stops the radar thread.
     * 
     */
    synchronized public void stopRunning() {
        if (this.running) {
            this.running = false; // Causes the loop to exit normally.
            
            try {
                this.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private volatile double myHeight, mySpeed;

    /**
     * Retrieve the height according to the radar.
     */
    public double getHeight() {
        return this.myHeight;
    }

    /**
     * Get the instantaneous speed calculated by the radar.
     */
    public double getSpeed() {
        return this.mySpeed;
    }
}
