package demo;
/*
 * demo/LaunchBoth.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * <p>
 * Launcher that starts both the simulation and controller in the same JVM. This
 * should be invoked instead of running two separate realtime JVMs on the same
 * machine. 
 * </p>
 * <p>
 * For example:
 * 
 * <pre>
 *    java -Xrealtime -mx256m -Xgc:scopedMemoryMaximumSize=11m demo.LaunchBoth 10101
 * </pre>
 * 
 * or if the realtime controller is being used:
 * 
 * <pre>
 *    java -Xrealtime -mx256m -Xgc:scopedMemoryMaximumSize=11m demo.LaunchBoth 10101 realtime
 * </pre>
 * 
 */
public class LaunchBoth {

    /**
     * 
     * @param args
     *            String[] with one argument specifying the port number to
     *            listen on, and another option that is specified if the
     *            realtime controller is being used.
     */
    public static void main(String[] args) {
        if (args.length < 1 || args.length > 2) {
            System.err.println("Usage: <port #> [realtime]");
            System.exit(1);
        }

        final int port = Integer.parseInt(args[0]);

        Thread simThread, controlThread;

        simThread = new Thread(new Runnable() {
            public void run() {
                String[] myArgs = new String[1];
                myArgs[0] = Integer.toString(port);
                demo.sim.SimLauncher.main(myArgs);
            }
        });

        if (args.length == 2 && args[1].equals("realtime")) {
            controlThread = new Thread(new Runnable() {
                public void run() {
                    String[] myArgs = new String[2];
                    myArgs[0] = "localhost";
                    myArgs[1] = Integer.toString(port);
                    demo.controller.RTJavaControlLauncher.main(myArgs);
                }
            });
        }else 
        if (args.length == 2) {
            controlThread = null;
            System.err.println("Usage: <port #> [realtime]");
            System.exit(1);
        } else {
            controlThread = new Thread(new Runnable() {
                public void run() {
                    String[] myArgs = new String[2];
                    myArgs[0] = "localhost";
                    myArgs[1] = Integer.toString(port);
                    demo.controller.JavaControlLauncher.main(myArgs);
                }
            });
        }

        simThread.start();
        try {
            Thread.sleep(2000l);
        } catch (InterruptedException e1) {
            e1.printStackTrace();
        }

        System.out.println("Starting control thread...");
        controlThread.start();

        try {
            controlThread.join();
            simThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
