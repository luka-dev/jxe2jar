package demo.comms;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.SocketException;
/*
 * demo/comms/EventPort.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * This is a communications port for the
 * simulation to send important events to the controller.
 * The events are just events to end the simulation - a crash
 * and a land event.
 *
 */
public class EventPort extends Port {    

    protected EventPort() throws SocketException {
        this.inBuffer = new byte[maxMessageSize];
        this.outBuffer = new byte[maxMessageSize];
        this.inPacket = new DatagramPacket(this.inBuffer, this.inBuffer.length);
        this.outPacket = new DatagramPacket(this.outBuffer, this.outBuffer.length);
    }
    
    /**** Events ****/
    
    /** A Crash - a catastrophic condition */
    public static final int E_CRSH = 0x43525348;
    
    /** A successful landing. */
    public static final int E_LAND = 0x4c414e44;
    
    /**
     * Called by simulation to receive events.
     * 
     * @return A 4 byte tag in an int
     * @throws IOException 
     */
    int receiveEvent() throws IOException {
        return this.receiveTag();
    }

    /**
     * Send a crash event to the controller.
     * 
     * @throws IOException
     */
    public void sendCrash() throws IOException {
        this.sendTag(E_CRSH);        
    }

    /**
     * Send a landing event to the controller.
     * 
     * @throws IOException
     */
    public void sendLanded() throws IOException {
        this.sendTag(E_LAND);
    }
    
}
