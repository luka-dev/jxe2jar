package demo.comms;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.SocketException;

/*
 * demo/comms/ControlPort.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * This Port is used for sending commands to the simulation and for
 * receiving the state of the simulation in the controller.
 *
 */
public class ControlPort extends Port {    
    // The largest message is the S_SNDV message.
    private static final int maxMessageSize = 4+   // Tag
                                              8+   // double X
                                              8+   // double vy
                                              8;   // double y

    public ControlPort() throws SocketException {
        this.inBuffer = new byte[maxMessageSize];
        this.outBuffer = new byte[maxMessageSize];
        this.socket.setTrafficClass(0x10); /* IPTOS_LOWDELAY */
        this.inPacket = new DatagramPacket(this.inBuffer, this.inBuffer.length);
        this.outPacket = new DatagramPacket(this.outBuffer, this.outBuffer.length);
    }
        
    /** Start the simulator */
    public static final int S_STRT = 0x53545254;
    /** End session */
    public static final int S_EXIT = 0x45584954;
   
    /**
     * The controller calls this to start the simulation
     * 
     * @throws IOException
     */
    public void sendStart() throws IOException {
        this.sendTag(S_STRT);
    }
     
    /**
     * This can be sent to stop the simulation.
     * 
     * @throws IOException
     */
    public void sendExit() throws IOException {
        this.sendTag(S_EXIT);
    }
    
    /**
     * Waits for the S_STRT (start) message.
     * 
     * @throws IOException
     */
    public void waitForStart() throws IOException {
        int tag = this.receiveTag();
        
        if(tag != S_STRT) {
            throw new IOException("Expecting S_STRT, received " + this);
        }
    }
    
    

    public static final int A_FIRL = 0x4649524c; /** Fire Left */

    public static final int A_FIRR = 0x46495252; /** Fire right */
    public static final int A_FIRO = 0x4649524f; /** Stop firing left/right */
    
    public static final int A_FIRD = 0x46495244; /** Fire down */
    public static final int A_FIRS = 0x46495253; /** Stop firing down */
    
    
    /**
     * Start firing the rocket that propels the lander to the left.
     * @throws IOException
     */
    public void sendFireLeft() throws IOException {
        this.sendTag(A_FIRL);
    }
    
    /**
     * Start firing the rocket that propels the lander to the right
     * @throws IOException
     */
    public void sendFireRight() throws IOException {
        this.sendTag(A_FIRR);
    }
    
    /**
     * Stops firing left or right.
     * 
     * @throws IOException
     */
    public void sendFireOff() throws IOException {
        this.sendTag(A_FIRO);
    }
    
    /**
     * Fires the descent engine.
     * 
     * @throws IOException
     */
    public void sendFireDown() throws IOException {
        this.sendTag(A_FIRD);
    }
    
    /**
     * Stop firing the descent engine.
     * @throws IOException
     */
    public void sendFireDownStop() throws IOException {
        this.sendTag(A_FIRS);
    }
    
    /** SNDV - send values */
    public static final int S_SNDV = 0x534e4456;

    /**
     * Called by the simulation to send the simulation state.
     * 
     * @param state A SimulationState structure filled with the simulations variables.
     * @throws IOException 
     */    
    public void sendState(SimulationState state) throws IOException {
        intToBytes(this.outBuffer,0,S_SNDV);
        doubleToBytes(this.outBuffer,4,state.getX());
        doubleToBytes(this.outBuffer,12,state.getVy());
        doubleToBytes(this.outBuffer,20,state.getY());
        
        if(trace) { trace("sendTag("+ this +")"+" x="+state.getX()+" vy="+state.getVy()+" y="+state.getY()); }
        
        this.socket.send(this.outPacket);
    }

    /** 
     * The controller calls this method to receive the simulation
     * state.
     * 
     * @return false if stop was received
     * @param state
     * @throws IOException
     */
    public boolean receiveState(SimulationState state) throws IOException {       
        int tag = this.receiveTag();        
        
        if(tag == S_STOP) {
            return false;
        }
        if(tag != S_SNDV) {
            throw new IOException("Invalid message - should be of type "+S_SNDV+" but is of type "+tag);
        }
        
        state.setX(bytesToDouble(this.inBuffer,4));
        state.setVy(bytesToDouble(this.inBuffer,12));
        state.setY(bytesToDouble(this.inBuffer,20));
        
        return true;        
    }
    
    /**
     * Simulation data is passed using this simple class. 
     *
     */
    static public class SimulationState {
        private double vy,x,y;
        
        public SimulationState() {  
            // This is used purely for information exchange.
        }
                
        public void setVy(double vy) {
            this.vy = vy;
        }
        
        public void setX(double x) {
            this.x = x;
        }
        
        public void setY(double y) {
            this.y = y;
        }
        
        public double getVy() {
            return this.vy;
        }
        
        public double getX() {
            return this.x;
        }
        
        public double getY() {
            return this.y;
        }
        
        public String toString() {
            return "vy="+this.vy+", x="+this.x+", y="+this.y;
        }
    }
}
