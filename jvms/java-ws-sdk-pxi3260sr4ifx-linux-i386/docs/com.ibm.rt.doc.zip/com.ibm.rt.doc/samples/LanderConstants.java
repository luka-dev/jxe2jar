package demo.common;
/*
 * demo/common/LanderConstants.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * Provides the constants for the Lander simulation.
 *
 */
public interface LanderConstants {

    /**
     * The width of the "landing pad". A successfull landing requires the
     * following to be true : -padWidth < x < padWidth
     */
    final public static double padWidth = 10.0;

    /**
     * This is the largest acceptable vertical speed on landing.
     */
    final public static double maxVy = -10.0;

    /**
     * The maximum horizontal speed (+/- this value)
     */
    final public static double maxVx = 5.0;

}