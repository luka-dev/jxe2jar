package demo.controller;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import demo.comms.*;
/*
 * demo/controller/JavaControlLauncher.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * <p>Launches the Simulation server. This should be run after the SimLauncher is run.
 * </p>
 * Usage:
 * <pre>
 *      java -Xrealtime -Xgc:scopedMemoryMaximumSize=10m demo.SimLauncher &lt;port&gt; [loop]
 * </pre>
 * 
 * The options are:
 * <dl>
 * <dt><code>&lt;port&gt;</code></dt>
 * <dd>Replace <code>&lt;port&gt;</code> with the UDP port number to wait for connections on.
 * </dd>
 * 
 * <dt><code>loop</code></dt>
 * <dd>This parameter is optional. If included, after a simulation has been run, the simulation
 * resets itself and waits again for a connection from the a client.
 * </dd> 
 * </dl>
 * </p>
 * <p>
 * The -Xrealtime option is required as the simulation uses the RTSJ classes.
 * 
 * Because the simulation uses scoped memory,<code>-Xgc:scopedMemoryMaximumSize=10m</code> is
 * required to allocate the memory.
 * 
 * <br/>
 * </p>
 */
public class JavaControlLauncher {

    public static void main(String[] args) {
        if (args.length != 2) {
            System.err.println("Arguments: <hostname> <port>");
            System.exit(1);
        }

        try {
            CommsControl commsControl = new CommsControl();

            commsControl.connect(InetAddress.getByName(args[0]), Integer
                    .parseInt(args[1]));

            ControlPort controlPort = commsControl.getControlPort();
            RadarPort radarPort = commsControl.getRadarPort();
            EventPort eventPort = commsControl.getEventPort();

            // Java version of Radar.
            JavaRadar radarJava = new JavaRadar(radarPort);
            Controller controller = new Controller(controlPort, radarJava);

            JavaControlThread javaControlThread = new JavaControlThread(
                    controller, radarJava);
            JavaEventThread javaEventThread = new JavaEventThread(eventPort,
                    javaControlThread);

            LoadThread loadThread = new LoadThread();
            loadThread.start(); // startup load

            javaEventThread.start();

            controlPort.sendStart();

            javaControlThread.start();

            try {
                javaControlThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }        
            
            controlPort.close();
            
            radarJava.stopRunning();
            
            javaEventThread.stopRunning();

        } catch (SocketException e) {
            System.err.println("SocketException thrown, exiting. " + e);
            e.printStackTrace();
        } catch (NumberFormatException e) {
            System.err.println("NumberFormatException thrown, exiting. " + e);
            e.printStackTrace();
        } catch (UnknownHostException e) {
            System.err.println("UnknownHostException thrown, exiting. " + e);
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("IOException thrown, exiting. " + e);
            e.printStackTrace();
        }

    }

}
