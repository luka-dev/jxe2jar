package demo.sim;

import java.io.IOException;

import javax.realtime.MemoryArea;
import javax.realtime.NoHeapRealtimeThread;
import javax.realtime.PeriodicParameters;
import javax.realtime.PriorityParameters;
import javax.realtime.PriorityScheduler;
import javax.realtime.RealtimeThread;
import javax.realtime.RelativeTime;
import javax.realtime.ReleaseParameters;

import demo.comms.ControlPort;
import demo.comms.EventPort;
import demo.comms.Port;
/*
 * demo/sim/SimulationThread.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * <p>
 * This is a thread the encapsulates the main loop of the simulation. To receive
 * commands from the controller, there is an inner class
 * <code>ListenThread</code>
 * 
 * </p>
 * <p>
 * The properties <code>demo.sim.simulationthread.initialHeight</code> and
 * <code>demo.sim.simulationthread.initialX</code> can be set to change the
 * default starting position of the lander.
 * </p>
 */
public class SimulationThread extends NoHeapRealtimeThread {

    /*
     * Ratio of periods executed to times a signal is sent to the controller.
     * e.g. if this is set to 10, the signal with the simulation values is sent
     * once every 10 periods.
     */
    private static final int signalModulo = 10;

    private ControlPort controlPort;

    private EventPort eventPort;

    private RadarThread radarThread;

    private final static double initialHeight;

    private final static double initialX;

    private final static int period = 20; // Simulation runs every 20ms

    private volatile boolean running = true;

    static {
        String initialHeightStr = System
                .getProperty("demo.sim.simulationthread.initialHeight");

        if (initialHeightStr != null) {
            initialHeight = Double.parseDouble(initialHeightStr);
        } else {
            initialHeight = 200.0;
        }

        String initialXStr = System
                .getProperty("demo.sim.simulationthread.initialX");

        if (initialXStr != null) {
            initialX = Double.parseDouble(initialXStr);
        } else {
            initialX = 100.0;
        }
    }

    /**
     * Creates a SimulationThread. The realtime parameters are embedded in the
     * constructor.
     * 
     * 
     * @param area
     *            The memory are to run the NHRT in
     * @param controlPort
     *            The control port to communicate through
     * @param eventPort
     *            The event port to listen to events with
     * @param radarThread
     *            The RadarThread to set the height into.
     */
    public SimulationThread(MemoryArea area, ControlPort controlPort,
            EventPort eventPort, RadarThread radarThread) {

        super(null, area);

        // Set priority separately, as we are using "this".
        // Note that PriorityScheduler.MAX_PRIORITY has been deprecated.
        this.setSchedulingParameters(new PriorityParameters(PriorityScheduler
                .getMaxPriority(this)));

        ReleaseParameters releaseParms = new PeriodicParameters(null,
                new RelativeTime(period, 0)); // 20ms cycle (50Hz)
        this.setReleaseParameters(releaseParms);

        // It is good practice to identify each of the threads.
        this.setName("SimulationThread");

        this.controlPort = controlPort;
        this.eventPort = eventPort;
        this.radarThread = radarThread;
    }

    /**
     * This thread runs the loop contained within that advances the simulation
     * and sends the simulation variables to the controller.
     */
    public void run() {
        Lander myLander = new Lander(initialX, initialHeight);
        ListenThread listenThread = new ListenThread(myLander, this.controlPort);

        listenThread.start();

        this.radarThread.setHeight(myLander.getY());

        try {
            this.controlPort.waitForStart();

            /* Once initialized, start */
            this.radarThread.start();
            int count = 0;

            try {
                ControlPort.SimulationState simState = new ControlPort.SimulationState();

                while (this.running) {

                    myLander.tick(((double) period) / 1e3);

                    this.radarThread.setHeight(myLander.getY());

                    simState.setVy(myLander.getVy());
                    simState.setX(myLander.getX());
                    simState.setY(myLander.getY());

                    // Reduces the rate at which we send state
                    if (count++ % signalModulo == 0) {
                        this.controlPort.sendState(simState);
                    }

                    if (myLander.landed() == true) {
                        this.running = false;
                        this.eventPort.sendLanded();
                    } else {
                        RealtimeThread.waitForNextPeriod();
                    }
                }
            } catch (Lander.CrashException e) {
                /* oops */
                System.out.println("CRASH! " + e);
                this.eventPort.sendCrash();
            }
        } catch (IOException e) {
            e.printStackTrace(); // Something bad happened.
        } finally {
            // Tell RT/JavaControlThread to stop,
            try {
                this.controlPort.sendTag(Port.S_STOP);
            } catch (IOException e1) {
                e1.printStackTrace();
            }

            // ListenThread will then receive OKAY from controller and exit.
            // Wait for the exit
            try {
                listenThread.join(); // Wait for ListenThread to be told to
                // stop.
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            // The RadarThread will then exit
            try {
                this.radarThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * This is the loop that waits for events from the controller. These events
     * are the rocket firing.
     */
    public static class ListenThread extends NoHeapRealtimeThread {
        private Lander lander;

        private ControlPort controlPort;

        public ListenThread(Lander lander, ControlPort controlPort) {
            // This thread implcitly runs in the same memory area it is created
            // in.
            super(null, getCurrentMemoryArea());
            this.setSchedulingParameters(new PriorityParameters(PriorityScheduler
                    .getMaxPriority(this)-2));
            
            this.setName("ListenThread");
            this.lander = lander;
            this.controlPort = controlPort;
        }

        private volatile boolean running = true;

        /**
         * Waits for commands from the controller, and relays them to the
         * Lander.
         */
        public void run() {
            try {
                while (this.running) {
                    int tag;
                    tag = this.controlPort.receiveTag();

                    switch (tag) {
                    case ControlPort.A_FIRD:
                        this.lander.fireDown();
                        break;
                    case ControlPort.A_FIRS:
                        this.lander.fireDownStop();
                        break;
                    case ControlPort.A_FIRR:
                        this.lander.fireRight();
                        break;
                    case ControlPort.A_FIRL:
                        this.lander.fireLeft();
                        break;
                    case ControlPort.A_FIRO:
                        this.lander.fireOff();
                        break;
                    case Port.S_OKAY:
                        // This is in reply to the stop sent by
                        // SimulationThread.
                        this.running = false;
                        break;
                    default:
                        throw new IOException(
                                "Unexpected tag received by ListenThread: "
                                        + this.controlPort);
                    }
                }
            } catch (IOException e) {
                this.running = false;
            }
        }
    }

}
