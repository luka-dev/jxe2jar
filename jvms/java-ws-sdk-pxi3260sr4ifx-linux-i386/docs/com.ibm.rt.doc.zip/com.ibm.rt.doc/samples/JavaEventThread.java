package demo.controller;

import java.io.IOException;

import demo.comms.EventPort;
/*
 * demo/controller/JavaEventThread.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * This is a thread that waits for the simulation to send notifications of
 * events. Methods that correspond with the events are executed in the
 * JavaControlThread class.
 * 
 * 
 * @see demo.comms.EventPort#E_LAND
 * @see demo.comms.EventPort#E_CRSH
 */
public class JavaEventThread extends Thread {
    private EventPort eventPort;

    private JavaControlThread javaControlThread;

    public JavaEventThread(EventPort eventPort,
            JavaControlThread javaControlThread) {
        this.setName("JavaEventThread");
        this.eventPort = eventPort;
        this.javaControlThread = javaControlThread;
    }

    public void run() {
        try {
            while (this.running) {
                int tag;

                tag = this.eventPort.receiveTag();

                switch (tag) {
                case EventPort.E_CRSH:
                    // Crash
                    this.javaControlThread.crash();
                    this.running = false;
                    break;
                case EventPort.E_LAND:
                    // LAND.
                    this.javaControlThread.land();
                    this.running = false;
                    break;
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            this.eventPort.close();
        }
    }

    private volatile boolean running = true;

    synchronized public void stopRunning() {
        if (this.running) {
            this.running = false;
            this.eventPort.close();
            try {
                this.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
