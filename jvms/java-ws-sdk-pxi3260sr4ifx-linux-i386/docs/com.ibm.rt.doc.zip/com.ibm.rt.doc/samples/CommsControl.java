package demo.comms;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;

import javax.realtime.MemoryArea;

import demo.common.IndirectRef;

/*
 * demo/comms/CommsControl.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */

/**
 * <p>Controls the creation of the 3 ports.
 * 
 * They are established in the following order.
 * <ol>
 * <li>ControlPort</li>
 * <li>RadarPort</li>
 * <li>EventPort</li>
 * </ol>
 * 
 * </p><p>
 * The simulator will call "new CommsControl()" then the
 * accept(port) method.
 * </p><p>
 * The controller will call "new CommsControl()" then the
 * connect(InetAddress, port) method to establish all of the connections.  
 * </p>
 */
public class CommsControl {
    ControlPort controlPort;
    
    RadarPort radarPort;
    
    EventPort eventPort;
    
    public CommsControl() throws SocketException {
        this.controlPort = new ControlPort();
        this.radarPort = new RadarPort();
        this.eventPort = new EventPort();
    }
    
    /**
     * <p>
     * This constructor creates the ports in the memory areas that
     * are passed as arguments. 
     * </p>
     * 
     * @param controlArea MemoryArea to allocate control port in.
     * @param radarArea MemoryArea to allocate radar port in.
     * @param eventArea MemoryArea to allocate event port in.
     * @throws SocketException
     */
    public CommsControl(MemoryArea controlArea, MemoryArea radarArea,
            MemoryArea eventArea) throws SocketException {
        
        final IndirectRef<SocketException> errorRef = new IndirectRef<SocketException>();
        
        controlArea.enter(new Runnable() {
            public void run() {
                try {
                    CommsControl.this.controlPort = new ControlPort();
                } catch (SocketException e) {
                    errorRef.ref = e;
                }
            }
        });
        
        // Exceptions aren't propogated outside of Runnables.
        // Here the SocketException is being rethrown if it was caught in the runnable.
        if (errorRef.ref != null) {
            throw errorRef.ref;
        }
        
        radarArea.enter(new Runnable() {
            public void run() {
                try {
                    CommsControl.this.radarPort = new RadarPort();
                } catch (SocketException e) {
                    errorRef.ref = e;
                }
            }
        });
        
        if (errorRef.ref != null) {
            throw errorRef.ref;
        }
        
        eventArea.enter(new Runnable() {
            public void run() {
                try {
                    CommsControl.this.eventPort = new EventPort();
                } catch (SocketException e) {
                    errorRef.ref = e;
                }
            }
        });
        
        if (errorRef.ref != null) {
            throw errorRef.ref;
        }
    }
    
    /**
     * Connects the controller (the client) to the simulation
     * (the server).
     * 
     * @param address
     * @param port
     * @throws IOException
     */
    public void connect(InetAddress address, int port) throws IOException {
        try {
            this.controlPort.connect(address, port);
            this.radarPort.connect(address, port + 1);
            this.eventPort.connect(address, port + 2);
        } catch (IOException e) {
            this.close();
            throw e;
        }
    }
    
    /**
     * Called by the server to wait for connections from the controller.
     * 
     * @param port
     * @throws IOException
     */
    public void accept(int port) throws IOException {
        try {
            this.controlPort.bind(port);
            this.radarPort.bind(port + 1);
            this.eventPort.bind(port + 2);
            
            this.controlPort.accept();
            this.radarPort.accept();
            this.eventPort.accept();
        } catch (IOException e) {
            this.close();
            throw e;
        }
    }
    
    /**
     * Returns the ControlPort.
     * Only useful after the connection has been established.
     * 
     * @return ControlPort
     */
    public ControlPort getControlPort() {
        return this.controlPort;
    }
    
    /**
     * Returns the RadarPort.
     * Only useful after the connection has been established.
     * 
     * @return RadarPort
     */
    public RadarPort getRadarPort() {
        return this.radarPort;
    }
    
    /**
     * Returns the EventPort.
     * Only useful after the connection has been established.
     * 
     * @return ControlPort
     */
    public EventPort getEventPort() {
        return this.eventPort;
    }
    
    /**
     * Call this once the ports are finished being used.
     *
     */
    public void close() {
        this.controlPort.close();
        this.radarPort.close();
        this.eventPort.close();
    }
}
