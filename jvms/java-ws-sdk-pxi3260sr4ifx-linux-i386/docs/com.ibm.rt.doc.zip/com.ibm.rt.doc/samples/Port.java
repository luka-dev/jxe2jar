package demo.comms;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
/*
 * demo/comms/Port.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * <p>
 * This provides a simple means of sending and receiving UDP packets.
 * Messages are in the form of a 4 byte tags, perhaps followed by binary
 * data.
 * Subclasses of this class provide their own tags and wrapper methods to
 * send.
 * </p>
 * <p>
 * Subclasses are expected to allocate the inBuffer, outBuffer and the
 * inPacket and outPacket.
 * <p>
 * The communications can be printed to the console by setting the property
 * <code>demo.comms.port.trace=true</code>
 * </p><p>Setting the property to <code>bt</code> will cause a backtrace to be
 * printed to the console as well as the trace information.
 * </p>
 * 
 */
public abstract class Port {
    DatagramSocket socket;

    // We need two packets from simultaneous sending and receiving.
    DatagramPacket inPacket, outPacket;

    // The maximum message size - 1 tag.
    static final int maxMessageSize = 4;
    
    byte[] inBuffer;
    byte[] outBuffer;

    final static protected boolean trace = System
            .getProperty("demo.comms.port.trace") != null;

    static final protected boolean traceBacktraces;
    
    static {
        if (trace) {

            traceBacktraces = System.getProperty("demo.comms.port.trace").equals("bt");
        }else {
            traceBacktraces = false;
        }
    }

    private String className = this.getClass().getName();

    protected void trace(String str) {
        
        synchronized(Port.class) {
        System.err.println(this.className + ": " + str);
        if (traceBacktraces) {
            Thread.dumpStack();
        }
        }
    }

    /** initiate session */
    public static final int S_HELO = 0x48454c4f;

    /** Acknowledge */
    public static final int S_OKAY = 0x4f4b4159;

    /**
     * An error condition. Handled as an event as these can occur at any time.
     */
    public static final int E_EROR = 0x45524f52;

    /**
     * Sent when the port has been closed.
     */
    public static final int S_STOP = 0x53544f50;
    
    /** Network ping and pong - for calibration */
    public static final int N_NPIG = 0x4e504947;

    public static final int N_NPOG = 0x4e504f47;

    protected Port() throws SocketException {
        this.socket = new DatagramSocket(null);
    }

    /**
     * Connects the port to the simulation.
     * 
     * @param host
     *            InetAddress of host to connect to
     * @param port
     *            Port number of simulation to connect to
     * @throws java.io.IOException
     */
    public void connect(InetAddress host, int port) throws IOException {
        /* Send HELO */
        /*
         * Receive HELO or throw IOException
         */
        this.socket.connect(host, port);

        int tries = 3; // Try 3 times.
        boolean retry;
        int tag = 0;

        this.socket.setSoTimeout(1000);
        do {
            this.sendTag(S_HELO);

            retry = false;
            try {
                tag = this.receiveTag();
            } catch (SocketTimeoutException e) {
                if (trace) {
                    trace("connect() : receiveTag timeout.");
                }
                retry = true;
                tries--;
            }

        } while (retry == true && tries > 0);

        if (tag != S_HELO) {
            throw new IOException("Expected HELO, received " + this);
        }

        this.socket.setSoTimeout(0);
    }

    /** 
     * Binds the socket to the given port number.
     * 
     * @param port
     *      UDP port to bind to
     * @throws SocketException
     */
    public void bind(int port) throws SocketException {
        this.socket.bind(new InetSocketAddress(port));
    }

    /**
     * Waits for a controller to connect to the simulation. 
     * After closing, a new Port should be created if the
     * service is to be restored.
     * 
     * @throws IOException
     */
    public void accept() throws IOException {
        /* On sim, we will already be bound to a port */
        /* wait for helo */
        /* connect to client */
        /* send HELO */

        int tag = this.receiveTag();

        if (tag != S_HELO) {
            throw new IOException("Unexpected tag " + this);
        }

        //      Address our sent packets to the same address we received from.
        this.outPacket.setSocketAddress(this.inPacket.getSocketAddress());

        this.sendTag(S_HELO);

        // From now on we will only accept connections from the initiating client.
        this.socket.connect(this.inPacket.getSocketAddress());
    }

    /**
     * Closes this port.
     * Once this has been called, do not use this Port again.
     * 
     * Anything blocking on a receive will exit.
     * 
     */
    public void close() {
        if (this.socket.isClosed() == false) {
            this.socket.close();
        }
    }

    /**
     * Sends the OKAY message.
     * Sent in reply to a "HELO" or a "STOP".
     * 
     * @throws IOException
     */
    public void sendOkay() throws IOException {
        this.sendTag(S_OKAY);
    }
    
    /** Sends the STOP message.
     * Expect an "OKAY" message to be sent in return.
     * 
     * @throws IOException 
     */
    public void sendStop() throws IOException {
        this.sendTag(S_STOP);
    }
    
    /**
     * Sends the STOP message to the other side, then waits for the reply "OKAY".
     * This ensures that both ends of the port are shutting down in a coordinated manner.
     * Sometimes it will be necessary for the "STOP" message sending and "OKAY" message
     * receiving to be performed individually.
     *
     */
    public void stop() {
        try {
            this.sendTag(S_STOP);
            
            while(this.receiveTag()!= S_OKAY) {
                // Ignore anything other than OK.
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /**
     * Sends a 4 byte tag.
     * 
     * @param tag An int with 4 bytes in ASCII.
     * @throws IOException
     */
    public void sendTag(int tag) throws IOException {
        intToBytes(this.outBuffer, 0, tag);
        if (trace) {
            trace("sendTag(" +  new String(this.outBuffer, 0, 4) + ")");
        }
        this.socket.send(this.outPacket);
        if (trace) {
            trace("sendTag() : ");
        }
    }

    /**
     * Receives a message and returns it's tag. The caller must then interpret
     * the tag accordingly and then get the rest of the message (if necessary)
     * before calling receiveTag again.
     * 
     * @return int Tag value
     * @throws IOException
     * @throws StopException 
     */
    public int receiveTag() throws IOException/*, StopException */{
        int tag;
        if (trace) {
            trace("receiveTag()");
        }

        do {
            this.socket.receive(this.inPacket);
            tag = bytesToInt(this.inBuffer, 0);

            if (trace) {
                trace("receiveTag() : " +  new String(this.inBuffer, 0, 4));
            }

            /*
             * If we receive a network ping, immediately send a reply, and
             * continue
             */
            /* Our callers don't have to deal with this. */
            if (tag == N_NPIG) {
                sendTag(N_NPOG);
            }
            
        } while (tag == N_NPIG);

        return tag;
    }

    /**
     * Converts an array of bytes into a int value, from offset in the array.
     * 
     * @param array the array of bytes from where the int is to be extracted
     * @param offset the offset into the array where the bytes are extracted
     * @return the int value extracted from the array
     */
    public static int bytesToInt(byte[] array, int offset) {
        return ((array[offset] << 24) | (array[offset + 1] << 16)
                | (array[offset + 2] << 8) | (array[offset + 3]));
    }

    /**
     * Converts an array of bytes into a long value, from offset in the array.
     * 
     * @param array the array of bytes from where the long is to be extracted
     * @param offset the offset into the array where the bytes are extracted
     * @return the long value extracted from the array
     */
    public static long bytesToLong(byte[] array, int offset) {
        long lvalue = (long) (((long) array[offset]) << 56)
                | ((((long) array[offset + 1]) & 0xffl) << 48)
                | ((((long) array[offset + 2]) & 0xffl) << 40)
                | ((((long) array[offset + 3]) & 0xffl) << 32)
                | ((((long) array[offset + 4]) & 0xffl) << 24)
                | ((((long) array[offset + 5]) & 0xffl) << 16)
                | ((((long) array[offset + 6]) & 0xffl) << 8)
                | (((long) array[offset + 7]) & 0xffl);

        return lvalue;
    }

    /**
     * Converts a int value into an array of 4 bytes,
     * starting at an offset.
     * 
     * @param array the array into which the bytes are put     
     * @param offset the offset into the array where the bytes are put
     * @param value the int value to be put into the array
     */
    public static void intToBytes(byte[] array, int offset, int value) {
        array[offset] = (byte) ((value >> 24) & 0xff);
        array[offset + 1] = (byte) ((value >> 16) & 0xff);
        array[offset + 2] = (byte) ((value >> 8) & 0xff);
        array[offset + 3] = (byte) (value & 0xff);
    }
    
    /**
     * Converts a long value into an array of 8 bytes,
     * starting at an offset.
     * 
     * @param array the array into which the bytes are put     
     * @param offset the offset into the array where the bytes are put
     * @param lvalue the long value to be put into the array
     */

    public static void longToBytes(byte[] array, int offset, long lvalue) {
        array[offset] = (byte) ((lvalue >>> 56) & 0xffl);
        array[offset + 1] = (byte) ((lvalue >>> 48) & 0xffl);
        array[offset + 2] = (byte) ((lvalue >>> 40) & 0xffl);
        array[offset + 3] = (byte) ((lvalue >>> 32) & 0xffl);
        array[offset + 4] = (byte) ((lvalue >>> 24) & 0xffl);
        array[offset + 5] = (byte) ((lvalue >>> 16) & 0xffl);
        array[offset + 6] = (byte) ((lvalue >>> 8) & 0xffl);
        array[offset + 7] = (byte) (lvalue & 0xff);
    }

    
    /**
     * Converts an array of bytes into a double value, from offset in the array.
     * 
     * @param array the array of bytes from where the double is to be extracted
     * @param offset the offset into the array where the bytes are extracted
     * @return the double value extracted from the array
     */
    public static double bytesToDouble(byte[] array, int offset) {
        return Double.longBitsToDouble(bytesToLong(array, offset));
    }

    /**
     * Converts a double value into an array of 8 bytes,
     * starting at an offset.
     * 
     * @param array the array into which the bytes are put     
     * @param offset the offset into the array where the bytes are put
     * @param value the double value to be put into the array
     */
    public static void doubleToBytes(byte[] array, int offset, double value) {
        long lvalue = Double.doubleToLongBits(value);
        longToBytes(array, offset, lvalue);
    }

    /**
     * 
     * @return String
     */
    public String toString() {
        String value = new String(this.inBuffer, 0, 4);

        return value;
    }
    
}
