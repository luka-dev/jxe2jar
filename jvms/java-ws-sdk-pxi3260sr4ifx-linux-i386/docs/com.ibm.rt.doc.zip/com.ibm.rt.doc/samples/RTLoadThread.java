package demo.controller;

import javax.realtime.LTMemory;
import javax.realtime.PriorityParameters;
import javax.realtime.PriorityScheduler;
import javax.realtime.RealtimeThread;
import javax.realtime.ScopedMemory;
import javax.realtime.SizeEstimator;
/*
 * demo/controller/RTLoadThread.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * <p>
 * This demonstrates that we can have significant memory allocation and
 * deallocation without having an appreciable impact on higher priority threads
 * in heaped memory.
 * </p>
 * <p>
 * The load can be changed from the default with the
 * <code>demo.controller.rtloadthread.load</code> property. The default is
 * 300000.
 * </p>
 */
public class RTLoadThread extends RealtimeThread {

    static final int load;
    static {
        String loadStr = System
                .getProperty("demo.controller.rtloadthread.load");

        if (loadStr != null) {
            load = Integer.parseInt(loadStr);
        } else {
            load = 300000;
        }

    }

    /**
     * Create a realtime daemon thread with the lowest priority (12).
     */
    public RTLoadThread() {
        super(new PriorityParameters(PriorityScheduler.MIN_PRIORITY));

        this.setName("RTLoadThread");
        this.setDaemon(true);
    }

    

    /**
     * This
     */
    public void run() {
        SizeEstimator size = new SizeEstimator();

        /**
         * Calulate the memory footprint of all the arrays and the array of
         * arrays.
         */
        size.reserve(long[][].class, load);
        size.reserve(long[].class, load * 50);
        ScopedMemory memArea = new LTMemory(size);

        while (true) {
            /*
             * A scoped memory area is being used. Normally the garbage
             * collector would have to deal with the unused classes, but with
             * scoped memory we are throwing away all of the objects in the
             * scope when we exit the enter() method. This will put much less
             * load on the garbage collector.
             * 
             */
            memArea.enter(new Runnable() {
                public void run() {
                    int count = 0;
                    long[][] array;
                    
                    array = new long[load][];
                    for (int n = 0; n < array.length; n++) {
                        array[count] = new long[50];
                        if (count++ % 1000 == 0) {
                            try {
                                sleep(1);
                            } catch (InterruptedException e) {
                                // Ignore this
                            }
                        }
                    }
                }
            });

        }
    }
}
