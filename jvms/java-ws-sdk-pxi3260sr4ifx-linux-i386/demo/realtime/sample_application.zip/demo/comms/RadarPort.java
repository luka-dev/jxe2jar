package demo.comms;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.SocketException;
/*
 * demo/comms/RadarPort.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * The controller uses this to send PING messages to
 * the simulation and time how long it takes for it
 * to reply with a PONG. 
 * 
 */
public class RadarPort extends Port {
    /** A pong was received. */
    public static final int E_PONG=0x50494e47;
    /** Send ping */
    public static final int A_PING=0x504f4e47;
    
    public RadarPort() throws SocketException {
        this.inBuffer = new byte[maxMessageSize];
        this.outBuffer = new byte[maxMessageSize];
        this.inPacket = new DatagramPacket(this.inBuffer, this.inBuffer.length);
        this.outPacket = new DatagramPacket(this.outBuffer, this.outBuffer.length);
    }
    
    /**
     * Called by controller, and expected to be timed in order to act as a judge of
     * the height of the lander.
     * @throws IOException 
     *
     */
    public void ping() throws IOException {
        this.sendTag(A_PING);
        int tag = this.receiveTag();
        
        if(tag != E_PONG) {
            throw new IOException("Unexpected response from Ping "+this);
        }
    }
    
    /**
     * Called by the simulation (server) to wait for a ping
     * 
     * @return false if STOP was received.
     * @throws IOException    
     */
    public boolean waitForPing() throws IOException {
        int tag = this.receiveTag();
        
        if(tag == S_STOP) {
            this.sendOkay();
            return false;
        }
        
        if(tag != A_PING) {
            throw new IOException("Expected E_PING, received "+this);
        }
        
        return true;
    }
    
    /**
     * Simulation calls this to reply to the ping.
     * 
     * @throws IOException
     */
    public void sendPong() throws IOException {
        this.sendTag(E_PONG);
    }
}
