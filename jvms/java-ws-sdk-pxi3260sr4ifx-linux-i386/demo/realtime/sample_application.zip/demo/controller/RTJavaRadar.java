package demo.controller;

import java.io.IOException;
import java.net.SocketException;

import javax.realtime.AbsoluteTime;
import javax.realtime.Clock;
import javax.realtime.MemoryArea;
import javax.realtime.NoHeapRealtimeThread;
import javax.realtime.PriorityParameters;
import javax.realtime.PriorityScheduler;

import demo.comms.RadarPort;
/*
 * demo/controller/RTJavaRadar.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * <p>
 * This class is a NoHeapRealtimeThread that times the time it takes to send a "PING"
 * packets to the simulation and receive the "PONG" packets. The length of the
 * delay is proportional to the height. The minimum period is 5ms, which
 * increases, depending on the height.
 * </p>
 * <p>
 * This Radar class is written for low heights. The greater the height, the less
 * frequently the height will be updated. When the height is at, say, 10000
 * units, the delay will be 5 seconds. During that time the position of the
 * lander will have changed so much that the speed and height will be very
 * inaccurate. As the controller doesn't anticipate the effects of accleration,
 * the vertical speed will not be properly controlled.
 * </p>
 */
public class RTJavaRadar extends NoHeapRealtimeThread implements Radar {
    private RadarPort radarPort;

    /**
     * Creates RTJavaRadar realtime thread with a priority of 20.
     * 
     * @param radarPort
     *            Radar port to communicate with.
     * @param memArea
     *            Memory area to run thread in.
     */
    public RTJavaRadar(RadarPort radarPort, MemoryArea memArea) {
        // There is no period as each radar cycle is of variable length.
        super(null, memArea);
        
        this.setSchedulingParameters(new PriorityParameters(PriorityScheduler
                .getMinPriority(this)+3));
        this.setName("RTJavaRadar");
        this.radarPort = radarPort;
    }

    /**
     * Times a ping/pong and calculates an estimated height for the lander.
     * 
     */
    public void run() {
        // The following objects are created in advance and reused each
        // iteration.
        Clock rtClock = Clock.getRealtimeClock();
        AbsoluteTime time = rtClock.getTime();

        try {
            double height = 0.0, lastheight;
            long millis = time.getMilliseconds(), lastmillis;
            long nanos = time.getNanoseconds(), lastnanos;

            while (this.running) {

                lastmillis = millis;
                lastnanos = nanos;
                lastheight = height;

                // Rather than use the time = rtClock.getTime() form, this
                // method
                // replaces the values in a preexisting AbsoluteTime object.
                rtClock.getTime(time);
                millis = time.getMilliseconds();
                nanos = time.getNanoseconds();

                // We time the time it takes to send the ping and receive the
                // pong.
                this.radarPort.ping();

                rtClock.getTime(time);

                height = (time.getMilliseconds() - millis)
                        / demo.sim.RadarThread.timeScale;
                height += ((time.getNanoseconds() - nanos) / 1.0e6)
                        / demo.sim.RadarThread.timeScale;

                double difference = ((double) (millis - lastmillis)) / 1.0e3
                        + ((double) (nanos - lastnanos)) / 1.0e9;
                double speed = (height - lastheight) / difference;

                this.myHeight = height;
                this.mySpeed = speed;

                try {
                    sleep(5);
                } catch (InterruptedException e) {
                    // This is not important.
                }
            }
        } catch (SocketException e) {
            // The socket exception is expected if this.running is false.
            if (this.running == true) {
                System.err.println("SocketException in RadarThread " + e);
                e.printStackTrace();
            }
        } catch (IOException e) {
            System.err.println("IOException in RadarThread");
            e.printStackTrace();
        } finally {
            this.radarPort.stop();
            this.radarPort.close();
        }
    }

    private volatile boolean running = true;

    /**
     * Flags the main loop that it should stop running and closes the RadarPort.
     */
    synchronized public void stopRunning() {
        if (this.running) {
            this.running = false; // Causes the loop to exit normally.
            try {
                this.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private volatile double myHeight, mySpeed;

    /**
     * Retrieve the height according to the radar.
     */
    public double getHeight() {
        return this.myHeight;
    }

    /**
     * Get the instantaneous speed calculated by the radar.
     */
    public double getSpeed() {
        return this.mySpeed;
    }
}
