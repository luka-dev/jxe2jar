package demo.controller;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

import javax.realtime.HeapMemory;
import javax.realtime.ImmortalMemory;
import javax.realtime.RealtimeThread;

import demo.common.IndirectRef;
import demo.comms.*;
/*
 * demo/controller/RTJavaControlLauncher.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * Launches Controller using realtime threads.
 * 
 */
public class RTJavaControlLauncher extends RealtimeThread {

    public static void main(String[] args) {
        if (args.length != 2) {
            System.err.println("Arguments: <hostname> <port>");
            System.exit(1);
        }

        // We need to use RealtimeThread as we are entering memory areas.
        RTJavaControlLauncher launcher = new RTJavaControlLauncher(args[0],
                args[1]);

        launcher.start();

        try {
            launcher.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public RTJavaControlLauncher(String host, String port) {
        this.setName("RTJavaControLauncher");
        this.host = host;
        this.port = Integer.parseInt(port);
    }

    String host;

    int port;

    public void run() {
        try {
            final CommsControl commsControl = new CommsControl(HeapMemory
                    .instance(), ImmortalMemory.instance(), HeapMemory
                    .instance());

            // These are used to pull the exceptions out of the Runnable and rethrow
            // them in this method.
            final IndirectRef<IOException> ioExRef = new IndirectRef<IOException>();
            final IndirectRef<UnknownHostException> uhExRef = new IndirectRef<UnknownHostException>();

            // The commsControl has to connect in immortal memory such that the
            // InetAddress is immortal, and hence accessible to the NHRT Radar.
            ImmortalMemory.instance().enter(new Runnable() {
                public void run() {
                    try {
                        commsControl.connect(InetAddress
                                .getByName(RTJavaControlLauncher.this.host),
                                RTJavaControlLauncher.this.port);
                    } catch (UnknownHostException e) {
                        e.printStackTrace();
                        uhExRef.ref = e;
                    } catch (IOException e) {
                        e.printStackTrace();
                        ioExRef.ref = e;
                    }

                }
            });

            if (ioExRef.ref != null) {
                throw ioExRef.ref;
            }
            if (ioExRef.ref != null) {
                throw uhExRef.ref;
            }

            ControlPort controlPort = commsControl.getControlPort();
            final RadarPort radarPort = commsControl.getRadarPort();
            EventPort eventPort = commsControl.getEventPort();

            final IndirectRef<RTJavaRadar> radarRef = new IndirectRef<RTJavaRadar>();

            // Create RTJavaRadar in Immortal, it is an NHRT.
            // If it was in scoped, it's interaction with the other threads would
            // be more complex.
            ImmortalMemory.instance().enter(new Runnable() {
                public void run() {
                    // Realtime version of Radar.
                    radarRef.ref = new RTJavaRadar(radarPort, ImmortalMemory
                            .instance());
                }
            });

            RTJavaRadar radarJava = radarRef.ref;
            
            Controller controller = new Controller(controlPort, radarJava);
            
            final RTJavaControlThread javaControlThread = new RTJavaControlThread(
                    controller, radarJava);

////             Run with scoped realtime load
//                        RTLoadThread rtloadThread = new RTLoadThread();
//                        rtloadThread.start(); // startup load
            
            // Run with ordinary thread, working on the heap
            LoadThread loadThread = new LoadThread();
            loadThread.start(); // startup load

            // Create event thread, then register the functionality we need with it's event handlers.
            RTJavaEventThread javaEventThread = new RTJavaEventThread(eventPort);
            
            // AEH runnable for land handler.
            javaEventThread.addLandHandler(new Runnable() {
                public void run() {
                    System.out.println("LAND!");
                }
            });

            // AEH runnable for crash handler.
            javaEventThread.addCrashHandler(new Runnable() {
                public void run() {
                    System.out.println("CRASH!");
                }
            });

            javaEventThread.start();

            controlPort.sendStart();

            javaControlThread.start();

            try {
                javaControlThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            
            controlPort.close();
            
            radarJava.stopRunning();
            
            javaEventThread.stopRunning();
        } catch (SocketException e) {
            System.err.println("SocketException thrown, exiting. " + e);
            e.printStackTrace();
        } catch (NumberFormatException e) {
            System.err.println("NumberFormatException thrown, exiting. " + e);
            e.printStackTrace();
        } catch (UnknownHostException e) {
            System.err.println("UnknownHostException thrown, exiting. " + e);
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("IOException thrown, exiting. " + e);
            e.printStackTrace();
        }

    }

}
