package demo.controller;

import java.io.IOException;
import java.net.SocketException;
/*
 * demo/controller/JavaControlThread.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * Executes the controller in an ordinary Java thread context.
 * 
 */
public class JavaControlThread extends Thread {
    private Controller controller;
    private JavaRadar radar;

    public JavaControlThread(Controller controller, JavaRadar radar) {
        this.setName("JavaControlThread");
        this.controller = controller;
        this.radar = radar;
    }

    /**
     * Starts RadarJavaThread. Repeatedly calls controller. Runs as slave to
     * values stream from
     * 
     */
    public void run() {
        this.radar.start();

        try {
            long lastmillis = System.currentTimeMillis();
            long millis = 0;

            while (this.running) {
                lastmillis = millis;
                millis = System.currentTimeMillis();

                this.running = this.controller.tick((millis - lastmillis) / 1e3);

            }
        }catch(SocketException e) {
            if (this.running == false) {
                System.out.println("Exiting...");
            }
        } catch (IOException e) {
            
            // What happened?
            e.printStackTrace();
        }finally{        
            this.controller.stopRunning();
        }
    }

    private volatile boolean running = true;

    /**
     * Stops this thread from running.
     * 
     */
    synchronized public void stopRunning() {
        if (this.running) {
            try {
                this.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Handle a crash.
     * 
     */
    public void crash() {
        System.out.println("CRASH!");
    }

    /**
     * Handle a land.
     * 
     */
    public void land() {
        System.out.println("LAND!");
    }
}
