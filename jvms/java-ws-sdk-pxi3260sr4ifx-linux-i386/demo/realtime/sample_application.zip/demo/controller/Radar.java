package demo.controller;
/*
 * demo/controller/Radar.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * Provides a common interface for the controller to
 * get the height and speed from JavaRadar and RTJavaRadar.
 */
public interface Radar {
    /**
     * @return Radar derived height
     */
    public abstract double getHeight();

    /**
     * @return Radar derived speed
     */
    public abstract double getSpeed();

}