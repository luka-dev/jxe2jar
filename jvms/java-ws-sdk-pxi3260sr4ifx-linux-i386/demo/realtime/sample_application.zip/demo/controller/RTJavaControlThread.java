package demo.controller;

import java.io.IOException;
import java.net.SocketException;

import javax.realtime.AbsoluteTime;
import javax.realtime.Clock;
import javax.realtime.PriorityParameters;
import javax.realtime.PriorityScheduler;
import javax.realtime.RealtimeThread;
import javax.realtime.RelativeTime;
/*
 * demo/controller/RTJavaControlThread.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * Executes the controller in a RealtimeThread context.
 * 
 */
public class RTJavaControlThread extends RealtimeThread {
    private Controller controller;

    private RTJavaRadar radar;

    public RTJavaControlThread(Controller controller, RTJavaRadar radar) {
        this.setSchedulingParameters(new PriorityParameters(PriorityScheduler
                .getMinPriority(this)+2));

        this.setName("RTJavaControlThread");

        this.controller = controller;
        this.radar = radar;
    }

    /**
     * Starts RTJavaRadar.
     * 
     */
    public void run() {
        this.radar.start();
        Clock rtclock = Clock.getRealtimeClock();
        AbsoluteTime time = rtclock.getTime(), lasttime = new AbsoluteTime();
        RelativeTime rtime = new RelativeTime();

        try {
            while (this.running) {
                lasttime.set(time);

                rtclock.getTime(time);

                time.subtract(lasttime, rtime);
                this.running = this.controller
                        .tick(rtime.getMilliseconds() / 1e3);
            } // while
        } catch (SocketException e) {
            if (this.running == false) {
                System.out.println("Exiting...");
            }
        } catch (IOException e) {
            // What happened?
            e.printStackTrace();

        } finally {
            // this.controller.stopRunning();
            this.controller.stopRunning();
        }
    }

    private volatile boolean running = true;

    /**
     * Stops this thread from running.
     * 
     */
    synchronized public void stopRunning() {
        if (this.running) {
            this.running = false;

            try {
                this.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
