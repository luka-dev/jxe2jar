package demo.controller;

import java.io.File;
import java.io.IOException;

import demo.common.LanderConstants;
import demo.comms.*;
import demo.comms.ControlPort.SimulationState;
/*
 * demo/controller/Controller.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * This is the logic and state for controlling the lander.
 * No thread is created by this thread. Instead, the thread
 * running the Controller should call the tick() method each
 * timeslice.
 */
public class Controller {
    
    // Descent at 9/10ths of the 
    private static final double descentRate = LanderConstants.maxVy * 0.9;

    // This is the minimum height if not over landing pad. 
    private static final double minHeight = 50.0;

    private static final int defaultHeight = 200;

    private static final int defaultX = 100;

    private ControlPort controlPort;
    
    private LandingGraph graph;
    private Radar radar;
    
    public Controller(ControlPort controlPort, Radar radar) {
        this.controlPort = controlPort;
        this.simState = new ControlPort.SimulationState();
        this.radar = radar;
        
        // Setup the speed averaging, 3 values per component.
        this.vxReg = new SpeedRegister(0.0, 3);
        this.vyReg = new SpeedRegister(0.0, 3);
        
        try {
            // Setup graph
            this.graph = new LandingGraph(new File("graph.svg"), defaultX, defaultHeight);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private SimulationState simState; // The comms layer puts values into here
    
    private double lastX, lastY;
    
    private SpeedRegister vxReg, vyReg;
    
    int traceCount = 0;
    
    /**
     * <p>
     * This is the main controller thread.
     * It gets state of the lander.
     * It then calculates what it should do...
     * Then fires the rockets appropriately.
     * </p><p>
     *  The controller controls the simulation by calculating
     *  a target horizontal and vertical speed then compares them
     *  against the speeds it has calculated (after applying smoothing)
     *  and decided what rockets to fire to match those speeds.
     *  There are three modes.
     *  <ol>
     *  <li>If height >50, move the lander over the pad, descending at a constant rate.</li>
     *  <li>If height <50, move the lander over the pad, maintaining height.</li>
     *  <li> Descend at a fixed rate, following the centre line of the landing pad.</li>
     * </p>
     * <p>
     * There is no anticipation in this algorithm, so the descent path will often overrun
     * the ideal path. 
     * </p> 
     * 
     * @param timeSinceLast A double value (in seconds) since last tick.
     * @throws IOException
     * @return false when stopped   
     */
    public boolean tick(double timeSinceLast) throws IOException {
        // Return's false if there is no more state to receive.
        if( this.controlPort.receiveState(this.simState) == false) {
            this.controlPort.sendOkay();
            return false;
        }

        
        double y = this.radar.getHeight();
        double speed = this.radar.getSpeed();
        
        double x = this.simState.getX();
        
        double ivy = speed;
        double ivx = (x - this.lastX) / timeSinceLast;
        double targetVx, targetVy;
        
        this.vxReg.addValue(ivx);
        double vx = this.vxReg.mean();
        
        this.vyReg.addValue(ivy);
        double vy = this.vyReg.mean();
    
        
        boolean fireLeft = false, fireRight = false, fireDown = false;
        
        /* Bring us down to landing point */
        if ((y > minHeight) && (Math.abs(x) > LanderConstants.padWidth)) {
            
            targetVx = (x / (y - minHeight)) * descentRate;
            targetVy = descentRate;
        } else if ((y < minHeight) && (Math.abs(x - vx) > LanderConstants.padWidth)) {
            /* Handles the case where we are low enough for approach,
             * but not over the landing pad
             */
            if (x > 0) {
                targetVx = -1.0;
            } else if (x < 0) {
                targetVx = 1.0;
            } else {
                targetVx = 0.0;
            }
            targetVy = 0.0;
        } else { /* Touch down */
            if (x > 0) {
                targetVx = -0.5;
            } else if (x < 0) {
                targetVx = 0.5;
            } else {
                targetVx = 0.0;
            }
            
            targetVy = descentRate; // Descent at 9/10ths of the max descent speed.
        }
        
        // Print out the status of the lander, add a point to the graph. 
        {
            this.traceCount++;
            
            if (this.traceCount % 10 == 0) {
//                System.out.println("X=" + x + ", radar=" + y + ", y="
//                        + this.simState.getY() + ", vx = " + vx + ", vy=" + vy
//                        + ", timeSinceLast=" + timeSinceLast + ", targetVx="
//                        + targetVx + ", targetVy=" + targetVy);
                System.out.println(
                        String.format("x=%1$.2f, radar=%2$.2f, y=%3$.2f, vx=%4$.2f, vy=%5$.2f, timeSinceLast=%6$.2f,"+
                                " targetVx=%7$.2f, targetVy=%8$.2f",
                                x,y,this.simState.getY(),vx,vy,timeSinceLast,targetVx,targetVy));
            }

            this.graph.addPoint((int) x, (int) this.simState.getY(),
                        (int) y);
        }
        
        if (vx - targetVx > 0.1) {
            fireLeft = true;
        }
        if (vx - targetVx < -0.1) {
            fireRight = true;
        }
        
        if (vy - targetVy < 0.0) {
            fireDown = true;
        }
        
        /*
         * At most we can send 1 horizontal command, and 1 vertical command.
         */
        if ((fireLeft && fireRight) || !(fireLeft || fireRight)) {
            this.controlPort.sendFireOff();
        } else if (fireLeft) {
            this.controlPort.sendFireLeft();
        } else if (fireRight) {
            this.controlPort.sendFireRight();
        }
        
        if (fireDown) {
            this.controlPort.sendFireDown();
        } else {
            this.controlPort.sendFireDownStop();
        }
        
        this.lastX = x;
        this.lastY = y;
        
        return true;
    }
    
    public String toString() {
        return "X=" + this.lastX + ", Y=" + this.lastY;
    }
    
    /**
     * Closes the control port, writes out the 
     *
     */
    synchronized public void stopRunning() {
        this.graph.write();        
    }
    
    /**
     * Smooths out variance in the speeds by buffering them and 
     * returning an average.
     */
    static class SpeedRegister {
        private int position = 0;
        
        double[] array;
        
        /**
         * 
         * @param initialv Value the array elements should be initialized too.
         * @param size The number of values to store and average over.
         */
        public SpeedRegister(double initialv, int size) {
            this.array = new double[size];
            for (int cnt = 0; cnt < size; cnt++) {
                this.array[cnt] = initialv;
            }
        }
        
        /**
         * Adds a value to the SpeedRegister.   
         * @param value to be added to the average
         */
        public void addValue(double value) {
            this.array[this.position] = value;
            this.position++;
            
            if (this.position == this.array.length) {
                this.position = 0;
            }
        }
        
        /**
         * 
         * @return The arithmetic mean of all the values.
         */
        public double mean() {
            double total = 0.0;
            for (int cnt = 0; cnt < this.array.length; cnt++) {
                total += this.array[cnt];
            }
            
            return total / this.array.length;
        }
    }
}
