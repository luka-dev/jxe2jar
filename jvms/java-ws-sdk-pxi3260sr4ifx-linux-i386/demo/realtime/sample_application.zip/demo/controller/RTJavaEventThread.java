package demo.controller;

import java.io.IOException;
import java.net.SocketException;

import javax.realtime.AsyncEvent;
import javax.realtime.AsyncEventHandler;
import javax.realtime.PriorityParameters;
import javax.realtime.PriorityScheduler;
import javax.realtime.RealtimeThread;

import demo.comms.EventPort;
/*
 * demo/controller/RTJavaEventThread.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * <p>
 * A restructured JavaEventThread that uses RTSJ's AsyncEvent mechanism.
 * </p>
 * <p>
 * There are two AsyncEvents created which will be fired when the appropriate
 * signals are received from the simulator. Methods calling addLandHandler() or
 * addCrashLander() can register Runnables that will be executed when the events
 * are fired.
 * </p>
 * 
 * 
 */
public class RTJavaEventThread extends RealtimeThread {
    private EventPort eventPort;

    private AsyncEvent landEvent = new AsyncEvent(),
            crashEvent = new AsyncEvent();

    public RTJavaEventThread(EventPort eventPort) {
        this.setSchedulingParameters(new PriorityParameters(PriorityScheduler
                .getMinPriority(this)+1));
        this.setName("RTJavaEventThread");
        this.eventPort = eventPort;
    }

    /**
     * Main loop that waits for events to be sent from the simulation.
     * 
     */
    public void run() {
        try {
            while (this.running) {
                int tag;

                tag = this.eventPort.receiveTag();

                switch (tag) {
                case EventPort.E_CRSH:
                    // Crash
                    this.crashEvent.fire();
                    this.running = false;
                    break;
                case EventPort.E_LAND:
                    // Land
                    this.landEvent.fire();
                    this.running = false;
                    break;
                }

            }
        } catch (SocketException e) {
            // This exit was normal if
            // this.running was false.
            if (this.running == true) {
                e.printStackTrace();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            this.eventPort.close();
        }

    }

    /**
     * Pass a runnable object that will be fired when the land event occurs.
     * 
     * @param runnable code to be executed when land event is triggered.
     */
    public void addLandHandler(Runnable runnable) {
        AsyncEventHandler handler = new AsyncEventHandler(runnable);
        this.landEvent.addHandler(handler);
    }

    /**
     * Pass a runnable object that will be run when the crash event occurs.
     * 
     * @param runnable code to be executed when crash event is triggered.
     */
    public void addCrashHandler(Runnable runnable) {
        AsyncEventHandler handler = new AsyncEventHandler(runnable);
        this.crashEvent.addHandler(handler);
    }

    private volatile boolean running = true;

    synchronized public void stopRunning() {
        if (this.running) {
            this.running = false;
            this.eventPort.close();
            try {
                this.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
