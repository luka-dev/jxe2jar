package demo.controller;

import java.io.PrintStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.LinkedList;
import java.io.File;

import demo.common.LanderConstants;
/*
 * demo/controller/LandingGraph.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * <p>
 * Produces an SVG diagram of the Lander's descent. There are two lines - the
 * path according to the simulation and the path according to the controller,
 * relying upon the radar for the height.
 * </p>
 * 
 * <p>
 * The methods must be called in the following order:
 * <ol>
 * <li>LandingGraph constructor.</li>
 * <li>addPoint(x, y, ry) ... as many times as there are points.</li>
 * <li>write();</li>
 * </ol>
 * 
 * 
 */
public class LandingGraph {
    private int height, width;
    
    private PrintStream out;
    
    // Adding elements to the LinkedList should be O(1).
    List<Point> points = new LinkedList<Point>();
    
    private final int scale = 2;
    
    /**
     * 
     * @param name
     *            of the File to write the svg too.
     * @param width
     *            maximum horizontal displacement
     * @param height
     *            maximum height.
     * @throws IOException
     */
    public LandingGraph(File name, int width, int height) throws IOException {
        this.out = new PrintStream(name);
        this.height = height * this.scale;
        this.width = width * this.scale;
    }
    
    /**
     * Write header for svg version 1.1 file. Draws the axis and additional
     * information.
     * 
     */
    private void writeHeader() {
        
        this.out.println("<?xml version=\"1.0\" standalone=\"no\"?>");
        
        this.out
        .println("<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\">");
        
        this.out
        .println("<svg viewBox=\""
                + -this.width
                + " 0 "
                + this.width
                + " "
                + this.height
                + "\""
                + " width=\"1024px\" height=\"768px\" xmlns=\"http://www.w3.org/2000/svg\">");
        
        // Draw grey grid behind
        this.out.println("<g stroke=\"lightgray\" fill=\"none\">"); // open grouping
        for (int y = 0; y < this.height; y += 10 * this.scale) {
            this.out.println("<line x1=\"" + (-this.width) + "\" y1=\"" + y
                    + "\" x2=\"" + this.width + "\" y2=\"" + y + "\" />");
        }
        for (int x = -this.width; x < this.width; x += 10 * this.scale) {
            this.out.println("<line x1=\"" + x + "\" y1=\"" + 0 + "\" x2=\""
                    + x + "\" y2=\"" + this.height + "\" />");
        }
        this.out.println("</g>"); // open grouping
        
        this.out.println("<g stroke=\"black\" fill=\"none\">"); // open grouping
        // Horizontal Axis
        this.out.println("<line x1=\"" + (-this.width) + "\" y1=\""
                + this.height + "\" x2=\"" + this.width + "\" y2=\""
                + this.height + "\" />");
        
        // Vertical axis
        this.out.println("<line x1=\"" + 0 + "\" y1=\"" + this.height
                + "\" x2=\"" + 0 + "\" y2=\"" + 0 + "\"/>");
        
        // landing pad limits
        this.out.println("<line x1=\"" + (-LanderConstants.padWidth)
                * this.scale + "\" y1=\"" + (this.height - 5) + "\" x2=\""
                + ((-LanderConstants.padWidth) * this.scale) + "\" y2=\""
                + this.height + "\"/>");
        
        this.out.println("<line x1=\"" + (LanderConstants.padWidth)
                * this.scale + "\" y1=\"" + (this.height - 5) + "\" x2=\""
                + ((LanderConstants.padWidth) * this.scale) + "\" y2=\""
                + this.height + "\"/>");
        this.out.println("</g>"); // close grouping
        
        // Draw text explaining colours.
        this.out.println("<g>");
        this.out
        .println("<text x=\"-200\" y=\"30\" font-size=\"10\">Radar Height in <tspan fill=\"blue\">blue</tspan></text>");
        this.out
        .println("<text x=\"-200\" y=\"40\" font-size=\"10\">Real Height in <tspan fill=\"red\">red</tspan></text>");
        this.out.println("</g>");
        
    }
    
    /**
     * Draw line for true position of the lander.
     */
    private void writeYs() {
        this.out
        .print("<polyline stroke=\"red\" fill=\"none\" stroke-opacity=\"0.5\" points=\"");
        
        Iterator<Point> pointIterator = this.points.iterator();
        
        while (pointIterator.hasNext()) {
            Point point = pointIterator.next();
            int x = point.x;
            int y = this.height - point.y;
            
            this.out.println("" + x + "," + y);
            
        }
        
        this.out.println("\"/>");
    }
    
    /**
     * Radar heights are drawn in blue.
     * 
     */
    private void writeRys() {
        
        this.out
        .print("<polyline stroke=\"blue\" fill=\"none\" stroke-opacity=\"0.5\" points=\"");
        Iterator<Point> pointIterator = this.points.iterator();
        
        while (pointIterator.hasNext()) {
            Point point = pointIterator.next();
            int x = point.x;
            int y = this.height - point.ry;
            
            this.out.println("" + x + "," + y);
        }
        
        this.out.println("\"/>");
    }
    
    private void close() {
        this.out.println("</svg>");
        this.out.close();
    }
    
    /**
     * Write out whole file, in order.
     * 
     */
    public synchronized void write() {        
        writeHeader();
        writeRys();
        writeYs();
        close();
    }
    
    /**
     * Adds a point to the graphs. For each position there is an x coordinate,
     * and two y coordinates.
     * 
     * @param x
     * @param y
     * @param radarY
     *            height as determined by the radar.
     */
    public void addPoint(int x, int y, int radarY) {
        this.points.add(new Point(x, y, radarY));
    }
    
    private class Point {
        public Point(int x, int y, int ry) {
            this.x = x * LandingGraph.this.scale;
            this.y = y * LandingGraph.this.scale;
            this.ry = ry * LandingGraph.this.scale;
        }
        
        int x, y, ry;
    }
}
