package demo.sim;

import java.io.IOException;
import java.net.SocketException;

import javax.realtime.*;

import demo.common.IndirectRef;
import demo.comms.*;
/*
 * demo/sim/SimLauncher.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * <p>Launches the Simulation server. This should be run before the JavaControlLauncher
 * or RTJavaControlLauncher is started.
 * </p>
 * <p>
 * Usage:
 * <pre>
 *      java -Xrealtime -Xgc:scopedMemoryMaximumSize=10m demo.SimLauncher &lt;port&gt; [loop]
 * </pre>
 * 
 * The options are:
 * <dl>
 * <dt><code>&lt;port&gt;</code></dt>
 * <dd>Replace <code>&lt;port&gt;</code> with the UDP port number to wait for connections on.
 * </dd>
 * 
 * <dt><code>loop</code></dt>
 * <dd>This parameter is optional. If included, after a simulation has been run, the simulation
 * resets itself and waits again for a connection from the a client.
 * </dd> 
 * </dl>
 * </p>
 * 
 * <p>
 * The -Xrealtime option is required as the simulation uses the RTSJ classes.
 * 
 * Because the simulation uses scoped memory,<code>-Xgc:scopedMemoryMaximumSize=10m</code> is
 * required to allocate the memory.
 * 
 * <br/>
 * </p>
 */
public class SimLauncher extends RealtimeThread {
    
    private int port; // The UDP port to listen on 
    
    public static void main(String[] args) {
        if ((args.length == 0) || 
            (args.length>2) || 
            ((args.length==2) && !args[1].equals("loop")))  {
            System.err.println("Usage: <port> [loop]");
            System.exit(1);
        }
        
        SimLauncher simLauncher;
        if(args.length==2) {
            simLauncher = new SimLauncher(Integer.parseInt(args[0]),true);
        }else{
            simLauncher = new SimLauncher(Integer.parseInt(args[0]),false);
        }
        
        simLauncher.start();
        
        try {
            simLauncher.join();
        } catch (InterruptedException e) {
            System.err.println("SimLauncher join interrupted");
            e.printStackTrace();
        }
    }
    
    /** 
     * Constructor for SimLauncher.
     * Only the port number is taken. 
     * This is a RealtimeThread that we are using just so we
     * can enter a scoped memory region to setup the NHRTs.
     */
    public SimLauncher(int port, boolean loop) {
        this.setName("demo.sim.SimLauncher");
        this.port = port;
        this.loop = loop;
    }
    
    private boolean loop;
    
    private volatile boolean running = true;
    
    public void stopRunning() {
        this.running = false;
    }

    /**
     * This run method is being used as the scoped memory area the NHRTs are
     * being run can only be created in a RealtimeThread context.
     */
    public void run() {       
        final IndirectRef<MemoryArea> myMemRef = new IndirectRef<MemoryArea>();
        
        /*
         * The VTMemory object has to be created in a memory area that the
         * NHRTs can access.
         */
        ImmortalMemory.instance().enter(new Runnable() {
            public void run() {
                //
                myMemRef.ref = new LTMemory(10000000); 
            }
        });
        
       final MemoryArea simMemArea = myMemRef.ref;
        
       /*
        * This is the main loop.
        */
        do{
            System.out.println("SimLauncher: Waiting for connections...");
                       
            final int portNum = this.port;
            
            simMemArea.enter(new Runnable() {
                public void run() {
                    try {
                        CommsControl commsControl = new CommsControl();
                        
                        ControlPort controlPort = commsControl.getControlPort();
                        RadarPort radarPort = commsControl.getRadarPort();
                        EventPort eventPort = commsControl.getEventPort();
                       
                        /* Create RadarThread.
                         * Started by simThread.
                         */
                        RadarThread radarThread = new RadarThread(simMemArea,
                                radarPort);

                        SimulationThread simThread = new SimulationThread(
                                simMemArea, controlPort, eventPort, radarThread);
                        
                        commsControl.accept(portNum);
                        
                        simThread.start();
                        
                        try {
                            simThread.join();
                        } catch (InterruptedException e) {
                            /* We were interrupted. Continue. */
                            e.printStackTrace();
                        }
                        
                        commsControl.close();
                    } catch (SocketException e) {
                        e.printStackTrace();
                        // How do I exit a loop outside this class?
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
        }while(this.running && this.loop);
    }
}
