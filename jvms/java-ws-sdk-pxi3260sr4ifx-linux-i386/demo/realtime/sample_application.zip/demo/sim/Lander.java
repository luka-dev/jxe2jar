package demo.sim;

import demo.common.LanderConstants;
/*
 * demo/sim/Lander.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * This class handles the "physics" of the simulated lunar lander. 
 * 
 * 
 */
public class Lander implements LanderConstants {

    private volatile double y, x; // vertical and horizontal position

    private volatile double vy, vx; // vertical and horizontal position

    private volatile double ax = 0.0; // Horizontal acceleration

    private double g = -1.0; // Acceleration due to gravity.

    public Lander(double x, double height) {
        this.x = x;
        this.y = height;
    }

    /**
     * This increments the position of the lander.
     * 
     * @param secs
     *            Length of time quantum to simulate.
     */
    public void tick(double secs) throws CrashException {
        if (this.y > 0.0) {
            double ay;
            ay = this.g;

            if (this.fired == true) {
                ay = 2.0;
            }
            this.y += this.vy * secs + ay * secs * secs * 0.5; // Calculate distance traveled
            this.vy += ay * secs; // Calculate the change in speed.

            this.x += this.vx * secs + this.ax * secs * secs * 0.5; // Calculate distance traveled
            this.vx += this.ax * secs; //Calculate the change in speed.

            // Determine whether or not the lander crashed or landed.
            if (this.y <= 0.0) {
                this.y = 0.0;
                boolean crash = false;
                String message = "";

                if (this.x < -padWidth || this.x > padWidth) {
                    crash = true;
                    message += "Didn't land on pad. (" + -padWidth + " to "
                            + padWidth + ")";
                }

                if (this.vx > maxVx) {
                    crash = true;
                    message += "Horizontal speed was too high. ";
                }

                if (this.vy < maxVy) {
                    crash = true;
                    message += "Vertical speed was too high. ";
                }

                if (crash == true) {
                    printStats();
                    throw new CrashException(message, this.x, this.vx, this.vy);
                } else {
                    printStats();
                    /* A successful landing. Well done to the controller */
                    this.vx = 0.0;
                    this.vy = 0.0;
                    this.landed = true;
                }
            }
        }
    }

    private boolean landed = false;

    /**
     * 
     * @return true if the lander has landed
     */
    public boolean landed() {
        return this.landed;
    }

    /**
     * This exception indicates that a crash occured.  
     */
    static public class CrashException extends Exception {
        private static final long serialVersionUID = 1321217430516190735L;

        private double x, vx, vy;

        public CrashException(String message, double x, double vx, double vy) {
            super(message + ", x=" + x + ", vx=" + vx + ", vy=" + vy);
            this.x = x;
            this.vx = vx;
            this.vy = vy;
        }

        public double getX() {
            return this.x;
        }

        public double getVx() {
            return this.vx;
        }

        public double getVy() {
            return this.vy;
        }
    }

    volatile private boolean fired;

    long nfired = 0, nfires = 0;

    /**
     * Counts number of control transitions. 
     * 
     */
    synchronized public void printStats() {
        System.out.println("Fire down transitions " + this.nfired
                + ", fire horizontally transitions " + this.nfires);
    }

    /**
     * Fires the "descent engine".
     */
    synchronized public void fireDown() {
        this.fired = true;
        this.nfired++;
    }

    /**
     * Stops firing the "descent engine".
     */
    synchronized public void fireDownStop() {
        this.fired = false;
        this.nfired++;
    }

    /**
     * Makes the lander accelerate to the left a bit.
     * 
     */
    synchronized public void fireLeft() {
        this.ax = -1.0;
        this.nfires++;
    }

    /**
     * Makes the lander accelerate to the right a bit.
     *
     */
    synchronized public void fireRight() {
        this.ax = 1.0;
        this.nfires++;
    }

    /**
     * Stops firing left or right
     *
     */
    synchronized public void fireOff() {
        this.ax = 0.0;
        this.nfires++;
    }

    public double getX() {
        return this.x;
    }

    public double getY() {
        return this.y;
    }

    public double getVx() {
        return this.vx;
    }

    public double getVy() {
        return this.vy;
    }
}
