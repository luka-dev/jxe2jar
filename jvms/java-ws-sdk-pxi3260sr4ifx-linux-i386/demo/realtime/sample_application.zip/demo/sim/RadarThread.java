package demo.sim;

import java.io.IOException;

import javax.realtime.MemoryArea;
import javax.realtime.NoHeapRealtimeThread;
import javax.realtime.PriorityParameters;
import javax.realtime.PriorityScheduler;
import javax.realtime.RelativeTime;

import demo.comms.RadarPort;
/*
 * demo/sim/RadarThread.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * <p>
 * This thread responds to "ping" messages from the controller with "pong"
 * messages. There is a pause between the two that is directly proportional to
 * the height of the lunar lander. The controller is expected to time this and
 * calculate the height.
 * </p>
 * <p>
 * The simulation calls the "setHeight()" method for this object to known the
 * height.
 * </p>
 */
public class RadarThread extends NoHeapRealtimeThread {
    private RadarPort radarPort;

    private volatile boolean running = true;

    // Upon receipt of a ping, the sending of the pong is delayed by
    // timeScale * height in milliseconds. From this the client can estimate
    // the height of the lander.
    public static final double timeScale = 2;

    public RadarThread(MemoryArea area, RadarPort radarPort) {
        super(null, area);

        // This is set separately, as we are using this.
        this.setSchedulingParameters(new PriorityParameters(PriorityScheduler
                .getMaxPriority(this)-1));

        setName("RadarThread");
        this.radarPort = radarPort;
    }

    private double height;

    /**
     * Set the height. The greater the height, the longer the return pong will
     * take. The SimulatorThread is expected to set this.
     * 
     * @param height
     */
    public void setHeight(double height) {
        this.height = height;
    }

    /**
     * The main loop.
     * 
     * 
     */
    public void run() {
        try {
            // RelativeTime can be reused.
            // This thread is run in ScopedMemory - a finite resource.
            RelativeTime relTime = new RelativeTime();

            while (this.running) {
                if (!this.radarPort.waitForPing()) {
                    this.running = false;
                    break;
                }

                /* 2 millis for each unit */
                relTime.set((long) (this.height * timeScale));

                /* wait for some time */
                try {
                    sleep(relTime);
                } catch (InterruptedException e) {
                    this.running = false;
                    // We'll end our final pong and exit.
                }
                this.radarPort.sendPong();
            }
        } catch (IOException e) {
            this.running = false;
        }
    }

    /**
     * Stops the RadarThread from running. Also closes its Port.
     */
    public void stopRunning() {
        this.running = false;
        this.radarPort.close();
        try {
            this.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
