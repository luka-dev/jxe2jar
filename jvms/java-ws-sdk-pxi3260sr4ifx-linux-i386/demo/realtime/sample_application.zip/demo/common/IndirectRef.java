package demo.common;
/*
 * demo/common/IndirectRef.java
 *
 * (C) COPYRIGHT International Business Machines Corp., 2006
 * All Rights Reserved * Licensed Materials - Property of IBM
 *
 * This program may be used, executed, copied, modified
 * and distributed without royalty for the purpose of
 * developing, using, marketing, or distributing.
 */
/**
 * <p>
 * This class is used to pass object references out of a Runnable that is
 * used to execute code within a memory area.
 * Caution should be used with scoped memory.
 * </p>
 * 
 */
public class IndirectRef<T> {
    public T ref;
}
